/*113. Create a class entering the command line arguments from the user and show all the arguments as output.*/


#include <iostream>

class CommandLineArguments {
private:
    int count;
    char **args;

public:
    CommandLineArguments(int argc, char* argv[]) : count(argc), args(argv) {}

    void displayArguments() {
        std::cout << "Command-line arguments:" << std::endl;
        for (int i = 0; i < count; ++i) {
            std::cout << args[i] << std::endl;
        }
    }
};

int main(int argc, char* argv[]) {
    CommandLineArguments cla(argc, argv);
    cla.displayArguments();

    return 0;
}


 output>>

Command-line arguments:


