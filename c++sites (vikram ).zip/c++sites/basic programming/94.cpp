/*94. Write a C++ program to calculate the sum of following series where n is input by user*/

#include<iostream>

using namespace std;

int main() {

int n,sum=0;

cout<<"Enter the numbers for n : ";
cin>>n;

for (int i = 1; i <=n; ++i)
{
      sum += i;   
}
cout<<"The sum of the series is : "<<sum;
return 0;

}